import ApplicationSchema from './Application'
import PostSchema from './Post'
export { ApplicationSchema, PostSchema }