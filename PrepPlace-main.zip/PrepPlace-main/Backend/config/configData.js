import 'dotenv/config'

const { DB_CONNECTION, SALT_ROUNDS } = process.env

export { DB_CONNECTION, SALT_ROUNDS }
