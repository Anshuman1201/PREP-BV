import React from 'react';
import pic from "../../images/1.png"

function Avatar() {
    return <img className="circle-img" src={pic} alt="avatar_img" />;
  }
  
  export default Avatar;